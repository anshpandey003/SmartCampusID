# Smart-Campus-ID
Smart Campus ID for VIT Chennai
